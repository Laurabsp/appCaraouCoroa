package com.example.caracoroa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
